@echo off
pushd "%~dp0"
".\pleiade.exe" --water-demo --cinematic --no-hud --asset-dir assets
popd
