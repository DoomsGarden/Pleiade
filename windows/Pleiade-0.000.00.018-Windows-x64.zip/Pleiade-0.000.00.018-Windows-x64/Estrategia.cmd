@echo off
pushd "%~dp0"
".\pleiade.exe" --fow-demo --materials --asset-dir assets
popd
