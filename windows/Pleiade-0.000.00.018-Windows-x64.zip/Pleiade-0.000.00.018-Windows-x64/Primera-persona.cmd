@echo off
pushd "%~dp0"
".\pleiade.exe" --walk-demo --materials --asset-dir assets
popd
